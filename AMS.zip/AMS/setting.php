
<?php 
session_start();
require 'init/db.class.php';
require 'init/userdata.php';
$data = new dbase();
$core = new core(); ?>
<!DOCTYPE html>
<html lang="en">

<head>

            <?php include 'includes/dh.php'; ?>

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
             <?php include 'includes/sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                        <?php include 'includes/topnav.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    

<div class="main pt-5">
<?php
$id = $_SESSION['id'];

if ($_POST){
        $oldPassword = $_POST['oldpassword'];
        $newpassword = $_POST['newpassword'];
        $repeatpassword = $_POST['repeatpassword'];
        //ENCRYPTED PASSWORD
        $encold = md5($oldPassword); 
        $encnew = md5($newpassword); 

        if (empty($oldPassword) || empty($newpassword) || empty($repeatpassword)){
            echo  '<span class="text-danger">All fields are required</span>';
            exit(0);
        }

        if ($newpassword != $repeatpassword){
            echo  '<span class="text-danger">New password do not match</span>'.'&nbsp;<a href="setting.php">Refresh</a>';
            exit(0);
        }

        $qry = $data->con->query("SELECT id FROM users WHERE password = '$encold' AND id = '$id'");
        if (mysqli_num_rows($qry) == false){
            echo  '<span class="text-danger">Old password is incorrect!</span>'.'&nbsp;<a href="setting.php">Refresh</a>';
            exit(0);
        }
        
        if ($data->con->query("UPDATE users SET password ='$encnew' WHERE id = '$id' ")){

            echo  '<span class="text-success">New password updated successfully</span>'.'&nbsp;<a href="setting.php">Refresh</a>';
        }



}


?>

 <form method="POST" autocomplete="off" >

          <section>

                 <div class="col-md-4 form-group">
                    <h3>CHANGE PASSWORD</h3>
                        <small>Keep your password safe</small>
                          <span class="password"></span> <span id="password"></span>
                 </div>

                 <div class="col-md-8 form-group">
                  <label>Old password</label>
                  <input type="password" required="required" name="oldpassword" class="form-control" >

                  <label>New password</label>
                  <input type="password" required="required" name="newpassword" class="form-control" >                  

                  <label>Repeat password</label>
                  <input type="password" required="required" name="repeatpassword" class="form-control" ><br>

                  <input type="submit" class="btn btn-info" value="Change Password" name=""> 
                  </div>
         </section>

    </form>

          </div>


                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Hardware Assets Management System 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Are you sure to logout?</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

   <!-- Bootstrap core JavaScript-->
    <?php include 'includes/bottomlinks.php'; ?>

</body>

</html>