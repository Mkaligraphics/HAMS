
<?php 
session_start();
require 'init/db.class.php';
require 'init/userdata.php';
$data = new dbase();
$core = new core(); 

if(!empty($_GET["action"])) {
switch($_GET["action"]) {
    case "add":
        if(!empty($_POST["quantity"])) {
            $asset = $core->runQuery("SELECT * FROM assets WHERE id='" . $_GET["assetid"] . "'");
            $itemArray = array($asset[0]["id"]=>array('productname'=>$asset[0]["productname"], 'model'=>$asset[0]["model"], 'quantity'=>$_POST["quantity"], 'amount'=>$asset[0]["amount"]));
            
            if(!empty($_SESSION["cart_item"])) {
                if(in_array($asset[0]["id"],array_keys($_SESSION["cart_item"]))) {
                    foreach($_SESSION["cart_item"] as $k => $v) {
                            if($asset[0]["id"] == $k) {
                                if(empty($_SESSION["cart_item"][$k]["quantity"])) {
                                    $_SESSION["cart_item"][$k]["quantity"] = 0;
                                }
                                $_SESSION["cart_item"][$k]["quantity"] += $_POST["quantity"];
                            }
                    }
                } else {
                    $_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$itemArray);
                }
            } else {
                $_SESSION["cart_item"] = $itemArray;
            }
        }
    break;
    case "remove":
        if(!empty($_SESSION["cart_item"])) {
            foreach($_SESSION["cart_item"] as $k => $v) {
                    if($_GET["assetid"] == $k)
                        unset($_SESSION["cart_item"][$k]);              
                    if(empty($_SESSION["cart_item"]))
                        unset($_SESSION["cart_item"]);
            }
        }
    break;
    case "empty":
        unset($_SESSION["cart_item"]);
    break;  
}
}
?>



<!DOCTYPE html>
<html lang="en">

<head>

            <?php include 'includes/dh.php'; ?>
              <!-- Cart css-->
    <link href="css/cart.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
             <?php include 'includes/sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                        <?php include 'includes/topnav.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">                   

     <div id="shopping-cart">
<div class="txt-heading">Shopping Cart</div>

<!-- All added carts-->
<br>
<button class="float-left btn btn-primary " type="submit" >Confirm sale</button>

<a id="btnEmpty" href="sales.php?action=empty">Empty Cart</a>
<?php
if(isset($_SESSION["cart_item"])){
    $total_quantity = 0;
    $total_price = 0;
?>  
<table class="tbl-cart" cellpadding="10" cellspacing="1">
<tbody>
<tr>
<th style="text-align:left;">Name</th>
<th style="text-align:left;">Model</th>
<th style="text-align:right;" width="5%">Quantity</th>
<th style="text-align:right;" width="15%">Unit Price</th>
<th style="text-align:right;" width="15%">Price</th>
<th style="text-align:center;" width="10%">Remove</th>
</tr>   
<?php       
    foreach ($_SESSION["cart_item"] as $item){
        $item_price = $item["quantity"]*$item["amount"];
        ?>
                <tr>
                <td><?php echo $item["productname"]; ?></td>
                <td><?php echo $item["model"]; ?></td>
                <td style="text-align:right;"><?php echo $item["quantity"]; ?></td>
                <td  style="text-align:right;"><?php echo "KSH ".$item["amount"]; ?></td>
                <td  style="text-align:right;"><?php echo "KSH ". number_format($item_price,2); ?></td>
                <td style="text-align:center;">
                    <a href="sales.php?action=remove&assetid=<?php echo $item["id"]; ?>" class="btnRemoveAction">
                      <span class="text-danger"><i class="fa fa-trash "></i> Remove</span>  
                    </a></td>
                </tr>
                <?php
                $total_quantity += $item["quantity"];
                $total_price += ($item["amount"]*$item["quantity"]);
        }
        ?>

<tr>
<td colspan="2" align="right">Total:</td>
<td align="right"><?php echo $total_quantity; ?></td>
<td align="right" colspan="2"><strong><?php echo "KSH ".number_format($total_price, 2); ?></strong></td>
<td></td>
</tr>
</tbody>
</table>        
  <?php
} else {
?>
<div class="no-records">Your Cart is Empty</div>
<?php 
}
?>
</div>

<div id="product-grid">
    <div class="txt-heading">Available assets</div>
    <?php
    $product_array = $core->runQuery("SELECT * FROM assets ORDER BY id ASC");
    if (!empty($product_array)) { 
        foreach($product_array as $key=>$value){
    ?>
        <div class="product-item">
            <form method="post" action="sales.php?action=add&assetid=<?php echo $product_array[$key]["id"]; ?>">
            <div class="product-tile-footer">
            <div class="product-title"><?php echo ucfirst($product_array[$key]["productname"]); ?></div>
            <div class="product-price"><?php echo "KSH".$product_array[$key]["amount"]; ?></div>
            <div class="cart-action"><input type="text" class="product-quantity" name="quantity" value="1" size="2" /><input type="submit" value="Add to Cart" class="btnAddAction" /></div>
            </div>
            </form>
        </div>
    <?php
        }
    }
    ?>
</div>               
<!-- All added carts-->




                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Hardware Assets Management System 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Are you sure to logout?</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

   <!-- Bootstrap core JavaScript-->
    <?php include 'includes/bottomlinks.php'; ?>

</body>

</html>