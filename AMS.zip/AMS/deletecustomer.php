<?php

require 'init/db.class.php';
 $data = new dbase();

if (isset($_GET['id'])){
 	$id = $_GET['id'];
 	if ($data->con->query("UPDATE customers SET active = '0' WHERE id = '$id'") ){
 		echo 'Customer successful deleted <a href="customereport.php">Back</a>'; 		
 	}
}


?>