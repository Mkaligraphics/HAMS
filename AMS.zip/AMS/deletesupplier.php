<?php

require 'init/db.class.php';
 $data = new dbase();

if (isset($_GET['id'])){
 	$id = $_GET['id'];
 	if ($data->con->query("UPDATE suppliers SET active = '0' WHERE id = '$id'") ){
 		echo 'Supplier successful deleted <a href="suppliereport.php">Back</a>'; 		
 	}
}


?>