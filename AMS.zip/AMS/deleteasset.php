<?php

require 'init/db.class.php';
 $data = new dbase();

if (isset($_GET['id'])){
 	$id = $_GET['id'];
 	if ($data->con->query("UPDATE assets SET active = '0' WHERE id = '$id'") ){
 		echo 'Asset successful deleted <a href="assetsreport.php">Back</a>'; 		
 	}
}


?>