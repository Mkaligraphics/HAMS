<?php

class core extends dbase{
	function loggedin() {
		if (isset($_SESSION['id']) && !empty($_SESSION['id'])){
			return true;
		}else {
			return false;
		}

	}

	//getting users fields
	function getfield($fields){
		$result = $this->con->query ("SELECT $fields FROM users WHERE id = '".$_SESSION['id']."' ") ;
		   $counts =  $result ->num_rows;
		   if ($counts > 0){
		   	while ($rw = mysqli_fetch_assoc($result)){
		  return $rw[$fields];
		   	}
	   }
	}

//Totalizer
	function staffs(){
		$result = $this->con->query ("SELECT count(id) FROM users WHERE active = '1' AND level !='admin' ") ;
			  	while ($rw = mysqli_fetch_array($result)){
			   	return $rw[0] > 0 || $rw[0] !== null ? $rw[0]:0;	 
	} }
	//end

	//Totalizer
	function assets(){
		$result = $this->con->query ("SELECT count(id) FROM assets WHERE active = '1' ") ;
			  	while ($rw = mysqli_fetch_array($result)){
			   	return $rw[0] > 0 || $rw[0] !== null ? $rw[0]:0;	 
	} }
	//end

	//Totalizer
	function customers(){
		$result = $this->con->query ("SELECT count(id) FROM customers WHERE active = '1' ") ;
			  	while ($rw = mysqli_fetch_array($result)){
			   	return $rw[0] > 0 || $rw[0] !== null ? $rw[0]:0;	 
	} }
	//end
	//Totalizer
	function suppliers(){
		$result = $this->con->query ("SELECT count(id) FROM suppliers WHERE active = '1'  ") ;
			  	while ($rw = mysqli_fetch_array($result)){
			   	return $rw[0] > 0 || $rw[0] !== null ? $rw[0]:0;	 
	} }
	//end

	function runQuery($query) {
		$result = mysqli_query($this->con,$query);
		while($row=mysqli_fetch_assoc($result)) {
			$resultset[] = $row;
		}		
		if(!empty($resultset))
			return $resultset;
	}
	
	function numRows($query) {
		$result  = mysqli_query($this->con,$query);
		$rowcount = mysqli_num_rows($result);
		return $rowcount;	
	}


}






?>