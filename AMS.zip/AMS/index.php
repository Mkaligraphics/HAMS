<?php
    session_start();
    require 'init/db.class.php';
    $data = new dbase();
?>

<!DOCTYPE html>
<html lang="en">

<head>
        <?php include 'includes/dh.php'; ?>
 
</head>

<body>

    <div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-10 col-lg-12 col-md-9">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4">Input your credential</h1>
                                    </div>

            <?php
    if (isset($_POST['submit'])){// post array
        if (!empty($_POST['username']) && !empty($_POST['password'])){ //if empty
            $username = $_POST['username'];
            $password = md5($_POST['password']) ;

            $user = $data->con->query("SELECT * FROM users WHERE idno = '$username' AND password = '$password'");
            if (mysqli_num_rows($user)> 0 ){
                    $identity = mysqli_fetch_array($user);
                    $id = $identity['id'];  
                    $_SESSION['id']= $id;
                    $ip = $_SERVER['REMOTE_ADDR']; //getting users ip address;     

             
                         $store_info = $data->con -> query("insert into logs (ip_addr,id) values 
    ('".$ip."','".$id."')") or die(mysqli_error($data->con));
                            header('location:dashboard.php');
                          
 
                    
            } else {
                echo '<span class="text-danger">Authentification failed</span>';
            }

        
    } else {
        echo 'All fields are required';
    }
}// end of post arrya
    ?>




                                    <form class="user" method="POST">
                                        <div class="form-group">
                                            <input type="number" name="username" class="form-control form-control-user"                                               
                                                placeholder="Enter username">
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control form-control-user"
                                                name="password" placeholder="Password">
                                        </div>
                                        
                                         <button type="submit"  class="btn btn-primary btn-user btn-block" name="submit">Login</button>
                                                                              
                                    </form>
                                   
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>

    <?php include 'includes/dfooter.php'; ?>

</body>

</html>