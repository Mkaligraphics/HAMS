 <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Register an asset</h1>                        
     
                    </div>
<?php
if (isset($_POST['submit'])){
    $supplier = $_POST['supplier']; 
    $model = $_POST['model'];
    $amount = $_POST['amount'];
    $product= $_POST['product'];
 

$data->con -> query("insert into assets (productname,model,amount, supplier ) values   ('".$product."','".$model."','".$amount."','".$supplier."')") or die(mysqli_error($data->con));

    // Simulate a mouse click:
    echo '<script>window.location.href =("assetsuccess.php");</script>';


}


?>

<form method="POST">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Product</label>
      <input type="text" class="form-control" name="product">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Model</label>
      <input type="text" class="form-control" name="model" >
    </div>
  </div>
  <div class="form-group">
    <label for="inputAddress">Amount</label>
    <input type="text" class="form-control" name="amount" >
  </div>
  <div class="form-group">
     <label for="inputState">Supplier</label>
      <select class="form-control" name="supplier">
          <?php
        ?>
        
        <?php   
        $result = $data->con->query("select * from suppliers where active = '1'") ;
                                              if ($result -> num_rows){
                                              while ($rw = $result->fetch_assoc()) { ?>
                                                <option><?php echo $rw['username']; ?></option>
        <?php }} ?>
      </select>
  </div> 
  <button type="submit" name="submit" class="btn btn-primary">Register</button>
</form>

