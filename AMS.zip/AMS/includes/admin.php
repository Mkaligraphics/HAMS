 <!-- Content Row -->
                                <?php include 'includes/contentrow.php'; ?>
                    <!-- Content Row -->  


                        <?php
if (isset($_POST['submit'])){
    $fname = $_POST['fname']; 
    $lname = $_POST['lname'];
    $idno = $_POST['idno'];
    $department= $_POST['department'];
    $mobile= $_POST['mobile'];
    $location = $_POST['location'];
    $password = md5($_POST['idno']);
 

$data->con -> query("insert into users (fname,lname,idno, phone, location, level, password ) values   ('".$fname."','".$lname."','".$idno."','".$mobile."','".$location."','".$department."','".$password."')") or die(mysqli_error($data->con));

    // Simulate a mouse click:
    echo '<script>window.location.href =("registersuccess.php");</script>';


}


?>

<form method="POST">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Fast name</label>
      <input type="text" class="form-control" name="fname">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Last name</label>
      <input type="text" class="form-control" name="lname" >
    </div>
  </div>
  <div class="form-group">
    <label for="inputAddress">Id number</label>
    <input type="text" class="form-control" name="idno" >
  </div>
  <div class="form-group">
     <label for="inputState">Department</label>
      <select class="form-control" name="department">
                    <option>procurement</option>
                    <option>finance</option>
                    <option>cashier</option>
              </select>
  </div> 

    <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Mobile</label>
      <input type="text" class="form-control" name="mobile">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Location</label>
      <input type="text" class="form-control" name="location" >
    </div>
  </div>


  <button type="submit" name="submit" class="btn btn-primary">Register</button>
</form>


