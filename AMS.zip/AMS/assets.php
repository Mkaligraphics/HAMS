
<?php 
session_start();
require 'init/db.class.php';
require 'init/userdata.php';
$data = new dbase();
$core = new core(); ?>
<!DOCTYPE html>
<html lang="en">

<head>

            <?php include 'includes/dh.php'; ?>

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
             <?php include 'includes/sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                        <?php include 'includes/topnav.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Register an asset</h1>                        
     
                    </div>
<?php
if (isset($_POST['submit'])){
    $supplier = $_POST['supplier']; 
    $model = $_POST['model'];
    $amount = $_POST['amount'];
    $product= $_POST['product'];
 

$data->con -> query("insert into assets (productname,model,amount, supplier ) values   ('".$product."','".$model."','".$amount."','".$supplier."')") or die(mysqli_error($data->con));

    // Simulate a mouse click:
    echo '<script>window.location.href =("assetsuccess.php");</script>';


}


?>

<form method="POST">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Product</label>
      <input type="text" class="form-control" name="product">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Model</label>
      <input type="text" class="form-control" name="model" >
    </div>
  </div>
  <div class="form-group">
    <label for="inputAddress">Amount</label>
    <input type="text" class="form-control" name="amount" >
  </div>
  <div class="form-group">
     <label for="inputState">Supplier</label>
      <select class="form-control" name="supplier">
        <option selected>Choose...</option>
          <?php
        ?>
        
        <?php   
        $result = $data->con->query("select * from suppliers") ;
                                              if ($result -> num_rows){
                                              while ($rw = $result->fetch_assoc()) { ?>
                                                <option><?php echo $rw['username']; ?></option>
        <?php }} ?>
      </select>
  </div> 
  <button type="submit" name="submit" class="btn btn-primary">Register</button>
</form>


                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Hardware Assets Management System 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Are you sure to logout?</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

   <!-- Bootstrap core JavaScript-->
    <?php include 'includes/bottomlinks.php'; ?>

</body>

</html>