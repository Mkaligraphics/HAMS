-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 20, 2021 at 10:34 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hams`
--

-- --------------------------------------------------------

--
-- Table structure for table `assets`
--

CREATE TABLE `assets` (
  `id` int(11) NOT NULL,
  `productname` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `supplier` varchar(100) NOT NULL,
  `recdate` datetime NOT NULL DEFAULT current_timestamp(),
  `active` tinyint(4) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `assets`
--

INSERT INTO `assets` (`id`, `productname`, `model`, `amount`, `supplier`, `recdate`, `active`) VALUES
(1, 'laptop', 'hp', '35000', 'sam tech', '2021-03-19 15:19:59', 0),
(2, 'computer', 'hp', '15000', 'marknet suppliers', '2021-03-19 15:21:15', 1);

-- --------------------------------------------------------

--
-- Table structure for table `costings`
--

CREATE TABLE `costings` (
  `id` int(11) NOT NULL,
  `duration` varchar(255) NOT NULL,
  `toolid` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `mobile` varchar(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `username`, `mobile`, `location`, `active`) VALUES
(1, 'Ken computers', '07 04487610', 'Tudor', 1);

-- --------------------------------------------------------

--
-- Table structure for table `hired`
--

CREATE TABLE `hired` (
  `id` int(11) NOT NULL,
  `toolid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `duration` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `recdate` datetime NOT NULL DEFAULT current_timestamp(),
  `status` int(11) NOT NULL DEFAULT 0,
  `returned` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `log_id` int(11) NOT NULL,
  `log_date` datetime NOT NULL DEFAULT current_timestamp(),
  `ip_addr` varchar(200) NOT NULL,
  `id` varchar(200) NOT NULL,
  `active` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`log_id`, `log_date`, `ip_addr`, `id`, `active`) VALUES
(1, '2021-03-19 08:46:03', '127.0.0.1', '2', 1),
(2, '2021-03-19 09:49:07', '127.0.0.1', '2', 1),
(3, '2021-03-19 12:49:14', '127.0.0.1', '2', 1),
(4, '2021-03-19 12:51:58', '127.0.0.1', '2', 1),
(5, '2021-03-19 12:53:27', '127.0.0.1', '2', 1),
(6, '2021-03-19 16:47:58', '127.0.0.1', '2', 1),
(7, '2021-03-20 07:22:27', '127.0.0.1', '1', 1),
(8, '2021-03-20 07:23:35', '127.0.0.1', '1', 1),
(9, '2021-03-20 07:45:59', '::1', '1', 1),
(10, '2021-03-20 07:53:25', '::1', '2', 1),
(11, '2021-03-20 07:59:34', '::1', '12', 1),
(12, '2021-03-20 08:02:44', '::1', '11', 1),
(13, '2021-03-20 09:19:03', '127.0.0.1', '1', 1),
(14, '2021-03-20 11:50:08', '127.0.0.1', '1', 1),
(15, '2021-03-20 12:27:37', '127.0.0.1', '2', 1),
(16, '2021-03-20 12:28:29', '127.0.0.1', '12', 1);

-- --------------------------------------------------------

--
-- Table structure for table `statement`
--

CREATE TABLE `statement` (
  `id` int(11) NOT NULL,
  `recdate` datetime NOT NULL DEFAULT current_timestamp(),
  `hiredid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `active` tinyint(10) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `username`, `address`, `mobile`, `email`, `active`) VALUES
(1, 'sam tech ', 'kilifi', '0716359560', 'samtech@gmail.com', 1),
(7, 'Two Million  ', 'nyali', '0726454841', 'twom@gamail.com ', 1),
(8, 'marknet suppliers ', 'moi avenue ', '0748695325', 'marknetsuppliers@gmail.com', 1),
(9, 'technologies limited ', 'docks ', '0777698523', 'technology@gmail.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tools`
--

CREATE TABLE `tools` (
  `id` int(11) NOT NULL,
  `toolname` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `upload` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `recdate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `idno` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `level` varchar(255) NOT NULL DEFAULT 'farmer',
  `recdate` datetime NOT NULL DEFAULT current_timestamp(),
  `active` tinyint(4) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `idno`, `phone`, `password`, `location`, `level`, `recdate`, `active`) VALUES
(1, 'Admin', 'adminstrator', '12345678', '0712345678', '81dc9bdb52d04dc20036dbd8313ed055', 'mombasa', 'admin', '2020-03-11 15:14:05', 1),
(2, 'Mwanajuma', 'Kahindi', '36715025', '0712345677', '81dc9bdb52d04dc20036dbd8313ed055', 'nairobi', 'procurement', '2020-03-11 15:33:03', 1),
(11, 'salma', 'khadija', '54677738', '0788999990', '81dc9bdb52d04dc20036dbd8313ed055', 'kisumu', 'finance', '2020-03-13 22:53:27', 1),
(12, 'Renish', 'Winslet', '12345666', '071234455', '81dc9bdb52d04dc20036dbd8313ed055', 'Mshomoroni', 'cashier', '2021-03-20 07:18:16', 1),
(14, 'fname', 'lname', '6666666', '0748695325', 'd5ee2eedfcf7adc285db4967bd86910d', 'maweni', 'finance', '2021-03-20 09:47:44', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assets`
--
ALTER TABLE `assets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `costings`
--
ALTER TABLE `costings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hired`
--
ALTER TABLE `hired`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `statement`
--
ALTER TABLE `statement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tools`
--
ALTER TABLE `tools`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assets`
--
ALTER TABLE `assets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `costings`
--
ALTER TABLE `costings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `hired`
--
ALTER TABLE `hired`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `statement`
--
ALTER TABLE `statement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tools`
--
ALTER TABLE `tools`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
